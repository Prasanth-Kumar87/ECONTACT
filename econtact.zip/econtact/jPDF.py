#! /usr/bin/python
import pandas as pd

print('ECONTACT Calculations to Identify Cross-talks between Amino Acids Involved in Ligand Binding using jPDF metric\n\nBefore proceeding the calculations, please ensure the preparation of two files: \n 1) Training_jPDF.csv -- comprises the values of two per-residue energy terms of cross-talks used to calibrate jPDF metric \n 2) Testing_jPDF.csv -- comprises the values of two per-residue energy terms of cross-talks which needs to be tested on the training complexes \n\njPDF Results:\n')

# Reading the Training_jPDF.csv and Testing_jPDF.csv containing per-residue energy terms of cross-talks
df = pd.read_csv('/home/binlab/Downloads/ECONTACT/Training_jPDF.csv', header=None, sep=',')
df1 = pd.read_csv('/home/binlab/Downloads/ECONTACT/Testing_jPDF.csv', header=None, sep=',')

# Scaling jPDF measure from training set
a,b = df.min()
c = a*b
g = []

# Computing the jPDF measure for test set
for x in range(0, len(df1)):
		m = df1[0][x]
		n = df1[1][x]
		f = (df1[0][x]*df1[1][x])
		f = f/c
		if(f > 1): 
			print (round(f,2),"*")
			g = 0
		else:
			print(round(f,2))

if g == 0:
	print("\n\n*The jPDF value for this complex is higher than support set generated from the training set. This indicates that this complex has strong interactions in accordance with the per-residue energy terms trained by ECONTACT approach")
