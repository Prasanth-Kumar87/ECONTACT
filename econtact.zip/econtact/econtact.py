#! /usr/bin/python
from matplotlib import pyplot as plt
import numpy as np
import math
import pandas as pd
import csv
import os

print('ECONTACT Calculations to Identify Cross-talks between Amino Acids Involved in Ligand Binding \n Before proceeding the calculations, please ensure the preparation of four files: \n 1) blac.data -- comprises the values of per-residue energy terms \n 2) energy.csv -- csv file containing the names of the per-residue energy terms \n 3) pc.csv -- csv file listing the index of the PC components \n 4) energy_terms_index.csv -- similar to file (2) but contains header information\n\nECONTACT Results:\n')

# Reading the maob.data containing per-residue energy terms 
df = pd.read_csv('/home/binlab/Downloads/ECONTACT/blac.data', header=None, sep=',')
r,c = df.shape
c = c-1
df.tail()
X = df.ix[:,0:c].values
fl = pd.DataFrame(X)
fl.to_csv("input_data.csv", index=True)

# Performing PCA calculations of per-residue energy terms
mean_vec = np.mean(X, axis=0)
cov_mat = (X - mean_vec).T.dot((X - mean_vec)) / (X.shape[0]-1)
cov_mat = np.cov(X.T)
eig_vals, eig_vecs = np.linalg.eig(cov_mat)
g = pd.DataFrame(eig_vecs.real)
g.to_csv(path_or_buf="results_table.csv",index=False)

# Assigning the row indexes (energy.csv) and column headers (pc.csv) to PCA results and printing the top five per-residue energy terms
exp_arr = []
for x in open("energy.csv"):
	exp_arr.append(x.replace("\n",""))
exp_col = []
for x in open("pc.csv"):
	exp_col.append(x.replace("\n",""))
df1 = pd.read_csv('results_table.csv', names=exp_col, header=None, sep=',')
df1.to_csv(path_or_buf="head_added_results.csv",index=False)
df2 = pd.read_csv("head_added_results.csv", usecols=['PC1'])
df2.index = exp_arr
df2.to_csv(path_or_buf="stripped_column.csv",index=True)
df2.sort_values(by=['PC1'], inplace=True, ascending=False)
df2.to_csv(path_or_buf="sorted_column.csv",index=True)
print("The top ten per-residue energy terms are:")
print(df2.head(10))
df3 = df2.head(10)
df3.to_csv(path_or_buf="top_10_energy_columns.csv",index=True)
values = df3.as_matrix(columns=df3.columns[0:])

# Reading the energy_terms_index.csv and extracting the top 10 per-residue energy terms from the original data by a column label search
df4 = pd.read_csv("energy_terms_index.csv", index_col="Energy_term")
c = df4.index.values
var0 = df3.index[0]
var1 = df3.index[1]
var2 = df3.index[2]
var3 = df3.index[3]
var4 = df3.index[4]
var5 = df3.index[5]
var6 = df3.index[6]
var7 = df3.index[7]
var8 = df3.index[8]
var9 = df3.index[9]
cl=list(c)

x=cl.index(var0)
x0 = x - 1
vary0 = df.iloc[ : , x0 ]
sr0 = vary0
sr0.to_csv('cross_terms0.csv', header=None, index=False)
x=cl.index(var1)
x1 = x - 1
vary1 = df.iloc[ : , x1 ]
sr1 = vary1
sr1.to_csv('cross_terms1.csv', header=None, index = False)
x=cl.index(var2)
x2 = x - 1
vary2 = df.iloc[ : , x2 ]
sr2 = vary2
sr2.to_csv('cross_terms2.csv', header=None, index = False)
x=cl.index(var3)
x3 = x - 1
vary3 = df.iloc[ : , x3 ]
sr3 = vary3
sr3.to_csv('cross_terms3.csv', header=None, index = False)
x=cl.index(var4)
x4 = x - 1
vary4 = df.iloc[ : , x4 ]
sr4 = vary4
sr4.to_csv('cross_terms4.csv', header=None, index = False)
x=cl.index(var5)
x5 = x - 1
vary5 = df.iloc[ : , x5 ]
sr5 = vary5
sr5.to_csv('cross_terms5.csv', header=None, index = False)
x=cl.index(var6)
x6 = x - 1
vary6 = df.iloc[ : , x6 ]
sr6 = vary6
sr6.to_csv('cross_terms6.csv', header=None, index = False)
x=cl.index(var7)
x7 = x - 1
vary7 = df.iloc[ : , x7 ]
sr7 = vary7
sr7.to_csv('cross_terms7.csv', header=None, index = False)
x=cl.index(var8)
x8 = x - 1
vary8 = df.iloc[ : , x8 ]
sr8 = vary8
sr8.to_csv('cross_terms8.csv', header=None, index = False)
x=cl.index(var9)
x9 = x - 1
vary9 = df.iloc[ : , x9 ]
sr9 = vary9
sr9.to_csv('cross_terms9.csv', header=None, index = False)
result = pd.concat([sr0, sr1, sr2, sr3, sr4, sr5, sr6, sr7, sr8, sr9], axis=1)
result.to_csv('checking.csv', header=None, index = False)

# Computing cross-terms using top ten per-residue energy functions
arr=[]
for i in range(0,len(result.values)):
	data=[]
	for x in range(0,len(result.values[i])+1):
		for y in range(x+1, len(result.values[i])):					
					data.append((result.values[i][x] * result.values[i][y]))
	arr.append(data)

arr=[]
for i in range(0,len(result.values)):
	data=[]
	for x in range(0,len(result.values[i])+1):
		for y in range(x+1, len(result.values[i])):					
			data.append((result.values[i][x] * result.values[i][y]))
	arr.append(data)
terms= pd.DataFrame(arr)
terms.to_csv("terms.csv",header=None,index=False)

# Assigning column headers to the cross-terms
named = pd.read_csv('terms.csv', header=None, sep=',')
m = [var0+":"+var1 , var0+":"+var2, var0+":"+var3, var0+":"+var4, var0+":"+var5, var0+":"+var6, var0+":"+var7, var0+":"+var8, var0+":"+var9, var1+":"+var2, var1+":"+var3, var1+":"+var4, var1+":"+var5, var1+":"+var6, var1+":"+var7, var1+":"+var8, var1+":"+var9, var2+":"+var3, var2+":"+var4, var2+":"+var5, var2+":"+var6, var2+":"+var7, var2+":"+var8, var2+":"+var9, var3+":"+var4, var3+":"+var5, var3+":"+var6, var3+":"+var7, var3+":"+var8, var3+":"+var9, var4+":"+var5, var4+":"+var6, var4+":"+var7, var4+":"+var8, var4+":"+var9, var5+":"+var6, var5+":"+var7, var5+":"+var8, var5+":"+var9, var6+":"+var7, var6+":"+var8, var6+":"+var9, var7+":"+var8, var7+":"+var9, var8+":"+var9]
named.columns = [m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15], m[16], m[17], m[18], m[19], m[20], m[21], m[22], m[23], m[24], m[25], m[26], m[27], m[28], m[29], m[30], m[31], m[32], m[33], m[34], m[35], m[36], m[37], m[38], m[39], m[40], m[41], m[42], m[43], m[44] ]
named.to_csv("cross_term_headers.csv",header=True,index=None)

# Removing the columns of cross-terms which contain negative values. Cross-terms are products of two per-residue energy terms carrying negative signs and this product should have positive values. Negative values in the cross-terms indicate one of the two per-residue energy terms contained positive value possibly through steric hindrence of ligand with the receptor and hence, its product carried negative sign
success = pd.read_csv('cross_term_headers.csv') 
success[success < 0] = "NEG"
success.to_csv('strip.csv', header=True, index=None)
cons = pd.read_csv('strip.csv')
(cons == 'NEG').any() 
ml = cons.loc[:, ~(cons == 'NEG').any()]
ml.to_csv('cross_terms_for_PCA.csv', header=True, index=None)

# Preparing the cross-terms for PCA calcualtions 
cross_term = pd.read_csv('cross_terms_for_PCA.csv', header=None, sep=',')
cross_term.drop([cross_term.index[0]], inplace=True)
cross_term.to_csv(path_or_buf="CCTT.csv",index=False)
CT = pd.read_csv('CCTT.csv', header=None, sep=',')
r1,c1 = CT.shape
CT.tail()
X = CT.ix[:,0:c1].values
fl1 = pd.DataFrame(X)
fl1.to_csv("input_data.csv", index=False)

#Performing PCA calculations of cross-terms
mean_vec = np.mean(X, axis=0)
cov_mat = (X - mean_vec).T.dot((X - mean_vec)) / (X.shape[0]-1)
cov_mat = np.cov(X.T)
eig_vals, eig_vecs = np.linalg.eig(cov_mat)
ge = pd.DataFrame(eig_vecs.real)
ge.to_csv(path_or_buf="final.csv",index=False)

#Performing manipulations to bring cross-term labels along with its PC loadings
ct = pd.read_csv('cross_term_headers.csv', sep=',')
ne = ct.transpose()
me = ne.loc[:, ne.columns == 0]
me.to_csv("1.csv", header=None)
ne1 = ge.loc[:, ge.columns == 0]
ne1.to_csv("2.csv", index=False, header=None)

with open('1.csv','rb') as f1, open('2.csv','rb') as f2, open('out.csv','wb') as w:
    writer = csv.writer(w)
    r1,r2 = csv.reader(f1),csv.reader(f2)
    while True:
        try:
            writer.writerow(next(r1)+next(r2))
        except StopIteration:
            break

colnames=[ 'Cross_talk', 'PCscore', 'Cross_term'] 
final = pd.read_csv('out.csv', names=colnames, header=None, sep=',')
final = final.drop(['PCscore'], axis = 1)
final.to_csv(path_or_buf="final.csv",index=True)
final1 = pd.read_csv("final.csv", usecols=['Cross_talk','Cross_term'])
final1.sort_values(by=['Cross_term'], inplace=True, ascending=False)
final1.to_csv(path_or_buf="top_2_cross_terms.csv")
print("\nThe top two cross terms identified by ECONTACT are:")
print(final1.head(2))
print("\nNEXT: Introduce the two per-residue energy terms participating in each cross-talk as two columns of a CSV file. Then, execute the python script jPDF.py for computing the strength of intermolecular interactions developed by any protein-ligand complex\n")

# Deleting unncessary files to free up space
os.remove("1.csv")
os.remove("2.csv")
os.remove("CCTT.csv")
os.remove("checking.csv")
os.remove("cross_terms0.csv")
os.remove("cross_terms1.csv")
os.remove("cross_terms2.csv")
os.remove("cross_terms3.csv")
os.remove("cross_terms4.csv")
os.remove("cross_terms5.csv")
os.remove("cross_terms6.csv")
os.remove("cross_terms7.csv")
os.remove("cross_terms8.csv")
os.remove("cross_terms9.csv")
os.remove("cross_terms_for_PCA.csv")
os.remove("cross_term_headers.csv")
os.remove("final.csv")
os.remove("head_added_results.csv")
os.remove("input_data.csv")
os.remove("out.csv")
os.remove("results_table.csv")
os.remove("sorted_column.csv")
os.remove("strip.csv")
os.remove("stripped_column.csv")
os.remove("terms.csv")
